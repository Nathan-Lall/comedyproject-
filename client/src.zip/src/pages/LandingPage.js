import React from 'react';


const Landingpage = () => {
    return (
    <body>
    <h1>Welcome to My Landing Page</h1>
    <div style="text-align:center;">
        <a href="https://www.example.com" target="_blank">
            <button>Enter</button>
        </a>
    </div>
</body>
    )
}
export default Landingpage;
